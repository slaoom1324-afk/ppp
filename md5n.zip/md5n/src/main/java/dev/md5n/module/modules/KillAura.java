package dev.md5n.module.modules;

import dev.md5n.module.Category;
import dev.md5n.module.Module;
import dev.md5n.setting.BoolSetting;
import dev.md5n.setting.ModeSetting;
import dev.md5n.setting.NumSetting;
import dev.md5n.util.Targets;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class KillAura extends Module {
    private final NumSetting range = num("Range", 3.0, 1.0, 6.0, 0.1, "Max attack distance");
    private final NumSetting minCooldown = num("Min Cooldown", 0.95, 0, 1, 0.05, "Attack only when your weapon is this charged");
    private final ModeSetting priority = mode("Priority", "Closest", "Which target to hit first", "Closest", "Lowest Health");
    private final BoolSetting players = bool("Players", true, "Attack players");
    private final BoolSetting hostile = bool("Hostile", true, "Attack hostile mobs");
    private final BoolSetting passive = bool("Passive", false, "Attack animals and villagers");
    private final BoolSetting visibleOnly = bool("Visible Only", true, "Ignore targets behind walls");
    private final BoolSetting faceTarget = bool("Face Target", false, "Turn your camera toward the target");
    private final BoolSetting pauseUsingItem = bool("Pause When Using Item", true, "Don't attack while eating or drawing a bow");

    public KillAura() {
        super("KillAura", Category.COMBAT, "Automatically attacks the best target in range");
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null) return;
        if (pauseUsingItem.get() && mc.player.isUsingItem()) return;

        LivingEntity target = findTarget();
        if (target == null) return;

        if (faceTarget.get()) faceTarget(target);

        if (mc.player.getAttackCooldownProgress(0.5f) < minCooldown.getFloat()) return;

        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    private void faceTarget(LivingEntity target) {
        Vec3d eye = mc.player.getEyePos();
        Vec3d aim = target.getPos().add(0, target.getHeight() * 0.7, 0);

        double dx = aim.x - eye.x;
        double dy = aim.y - eye.y;
        double dz = aim.z - eye.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);

        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));

        mc.player.setYaw(yaw);
        mc.player.setPitch(MathHelper.clamp(pitch, -90f, 90f));
    }

    private LivingEntity findTarget() {
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        boolean byHealth = priority.is("Lowest Health");

        for (Entity e : mc.world.getEntities()) {
            if (!Targets.valid(e, players.get(), hostile.get(), passive.get())) continue;
            LivingEntity living = (LivingEntity) e;

            double dist = mc.player.distanceTo(living);
            if (dist > range.get()) continue;
            if (visibleOnly.get() && !mc.player.canSee(living)) continue;

            double score = byHealth ? living.getHealth() : dist;
            if (score < bestScore) {
                best = living;
                bestScore = score;
            }
        }
        return best;
    }
}
