package dev.md5n.module.modules;

import dev.md5n.module.Category;
import dev.md5n.module.Module;
import dev.md5n.setting.NumSetting;

public class Sprint extends Module {
    private final NumSetting minFood = num("Min Food", 6, 0, 20, 1, "Stop sprinting at or below this hunger level");

    public Sprint() {
        super("Sprint", Category.MOVEMENT, "Always sprint while moving forward");
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (mc.options.forwardKey.isPressed()
                && !mc.player.horizontalCollision
                && !mc.player.isSneaking()
                && mc.player.getHungerManager().getFoodLevel() > minFood.getInt()) {
            mc.player.setSprinting(true);
        }
    }
}
