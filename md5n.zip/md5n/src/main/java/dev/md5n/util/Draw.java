package dev.md5n.util;

import net.minecraft.client.gui.DrawContext;

public final class Draw {
    private Draw() {}

    public static int alpha(int color, float f) {
        int a = (int) (((color >>> 24) & 0xFF) * Math.max(0f, Math.min(1f, f)));
        return (a << 24) | (color & 0x00FFFFFF);
    }

    public static int lerp(int a, int b, float t) {
        int aa = (a >>> 24) & 0xFF, ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int ba = (b >>> 24) & 0xFF, br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        int ra = (int) (aa + (ba - aa) * t);
        int rr = (int) (ar + (br - ar) * t);
        int rg = (int) (ag + (bg - ag) * t);
        int rb = (int) (ab + (bb - ab) * t);
        return (ra << 24) | (rr << 16) | (rg << 8) | rb;
    }

    /** مستطيل بزوايا مدورة (تقريب بخطوط أفقية). */
    public static void roundRect(DrawContext ctx, int x1, int y1, int x2, int y2, int r, int color) {
        r = Math.max(0, Math.min(r, Math.min((x2 - x1) / 2, (y2 - y1) / 2)));
        if (r == 0) {
            ctx.fill(x1, y1, x2, y2, color);
            return;
        }
        ctx.fill(x1, y1 + r, x2, y2 - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int dx = r - (int) Math.round(Math.sqrt(Math.max(0.0, (double) r * r - dy * dy)));
            ctx.fill(x1 + dx, y1 + i, x2 - dx, y1 + i + 1, color);
            ctx.fill(x1 + dx, y2 - i - 1, x2 - dx, y2 - i, color);
        }
    }

    /** لوحة زجاجية: توهج خفيف + إطار + تعبئة شبه شفافة. الألوان تمرّ جاهزة (مع الشفافية). */
    public static void glass(DrawContext ctx, int x1, int y1, int x2, int y2, int r, int fill, int border, int glow) {
        for (int i = 3; i >= 1; i--) {
            roundRect(ctx, x1 - i, y1 - i, x2 + i, y2 + i, r + i, glow);
        }
        roundRect(ctx, x1, y1, x2, y2, r, border);
        roundRect(ctx, x1 + 1, y1 + 1, x2 - 1, y2 - 1, Math.max(0, r - 1), fill);
    }

    /** تدرج عمودي من لون لآخر (بشرائح). */
    public static void vGradient(DrawContext ctx, int x1, int y1, int x2, int y2, int top, int bottom, int step) {
        int h = y2 - y1;
        if (h <= 0) return;
        for (int y = 0; y < h; y += step) {
            float t = (float) y / h;
            ctx.fill(x1, y1 + y, x2, Math.min(y2, y1 + y + step), lerp(top, bottom, t));
        }
    }
}
